function replyLoadHandler() {
	const replyDiv = document.getElementById('reply')
	replyDiv.innerText = '여기에 댓글을 불러옵니다'	
	
	const url = cpath + '/getReply'
	fetch(url + '?idx=' + board_idx)
	.then(resp => resp.json())
	.then(json => {
// 		console.log(json)

		const arr = json.map(item => {
			return {'idx': item.idx, 'writer': item.writer, 'content': item.content, 'writeDate': item.writeDate}
		})
		
		console.log(arr)
		replyDiv.innerHTML = ''
		
		arr.forEach(dto => {
			const html = convertHTMLfromJSON(dto)
			replyDiv.innerHTML += html
		})
// 		arr.forEach(e => {
// 			const reply_item = document.createElement('div')
// 			reply_item.classList.add('item')
			
// 			const reply_head = document.createElement('div')
// 			reply_head.classList.add('head')
			
// 			const reply_idx = document.createElement('div')
// 			reply_idx.classList.add('idx')
// 			reply_idx.innerText = '댓글 번호 : ' + e.idx
			
// 			const reply_date = document.createElement('div')
// 			reply_date.classList.add('date')			
// 			reply_date.innerText = yyyyMMdd(e.writeDate)
			
// 			const reply_writer = document.createElement('div')
// 			reply_writer.classList.add('writer')
// 			reply_writer.innerText = '작성자 : ' + e.writer
			
// 			const reply_content = document.createElement('div')
// 			reply_content.classList.add('content')
// 			reply_content.innerText = '내용 : ' + e.content
			
// 			reply_head.appendChild(reply_idx)
// 			reply_head.appendChild(reply_date)
// 			reply_item.appendChild(reply_head)
// 			reply_item.appendChild(reply_writer)
// 			reply_item.appendChild(reply_content)
// 			replyDiv.appendChild(reply_item)
// 		})
		
	})
}

function convertHTMLfromJSON(dto) {
	// JSON 객체를 받아서
	// HTML 태그형식으로 문자열을 반환해야 한다
	
	let html = `<div class="reply" idx="${dto.idx}">`
	html += `		<div class="replyTop">`
	html += `			<div class="left">`
	html += `				<div class="writer">${dto.writer}</div>`
	html += `				<div class="writeDate">${getYYYYMMDD(dto.writeDate)}</div>`
	html += `			</div>`
	html += `			<div class="right">`
	html += `				<button>수정</button>`
	html += `				<button>삭제</button>`
	html += `			</div>`
	html += `		</div>`
	html += `		<pre class="content">${dto.content}</pre>`
	html += `	</div>`
	return html
}

function getYYYYMMDD(date) {
	const newDate = new Date(date)
	const yyyy = newDate.getFullYear()
	let mm = newDate.getMonth() + 1
	let dd = newDate.getDate()		
	
	mm = mm < 10 ? '0' + mm : mm
	dd = dd < 10 ? '0' + dd : dd	
	
	return `${yyyy}-${mm}-${dd}`
}